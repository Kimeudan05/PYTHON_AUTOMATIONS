This is the best option if you want to share your app or run it without Python installed.

🛠️ Using pyinstaller

### 1. Install pyinstaller:

```
pip install pyinstaller
```

### 2. Build your app:

```
pyinstaller --noconsole --onefile --icon=icon.ico gui_cleaner.py
```

_(If you don’t have an icon, remove the --icon part.)_

### 3. After it finishes, check inside:

`dist/gui_cleaner.exe`

### 4.Double-click that `.exe` — your app will launch just like a native Windows application
